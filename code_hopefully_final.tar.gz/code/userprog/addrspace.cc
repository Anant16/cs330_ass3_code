// addrspace.cc 
//	Routines to manage address spaces (executing user programs).
//
//	In order to run a user program, you must:
//
//	1. link with the -N -T 0 option 
//	2. run coff2noff to convert the object file to Nachos format
//		(Nachos object code format is essentially just a simpler
//		version of the UNIX executable object code format)
//	3. load the NOFF file into the Nachos file system
//		(if you haven't implemented the file system yet, you
//		don't need to do this last step)
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "addrspace.h"
#include "noff.h"

extern void HandlePageFault(int vaddr);
extern void PageReplacementUpdater(int physicalAddress);
extern void LoadFromFile(int vaddr, int pageFrame);
extern void LoadThePage(int vaddr, int pageFrame);
extern void FreeThePage(int pageFrame);
//extern int FindPageToReplace(unsigned *pframe);
extern void PageReplacementHandler(int vaddr);

//----------------------------------------------------------------------
// SwapHeader
// 	Do little endian to big endian conversion on the bytes in the 
//	object file header, in case the file was generated on a little
//	endian machine, and we're now running on a big endian machine.
//----------------------------------------------------------------------

static void 
SwapHeader (NoffHeader *noffH)
{
	noffH->noffMagic = WordToHost(noffH->noffMagic);
	noffH->code.size = WordToHost(noffH->code.size);
	noffH->code.virtualAddr = WordToHost(noffH->code.virtualAddr);
	noffH->code.inFileAddr = WordToHost(noffH->code.inFileAddr);
	noffH->initData.size = WordToHost(noffH->initData.size);
	noffH->initData.virtualAddr = WordToHost(noffH->initData.virtualAddr);
	noffH->initData.inFileAddr = WordToHost(noffH->initData.inFileAddr);
	noffH->uninitData.size = WordToHost(noffH->uninitData.size);
	noffH->uninitData.virtualAddr = WordToHost(noffH->uninitData.virtualAddr);
	noffH->uninitData.inFileAddr = WordToHost(noffH->uninitData.inFileAddr);
}

//----------------------------------------------------------------------
// ProcessAddressSpace::ProcessAddressSpace
// 	Create an address space to run a user program.
//	Load the program from a file "executable", and set everything
//	up so that we can start executing user instructions.
//
//	Assumes that the object code file is in NOFF format.
//
//	First, set up the translation from program memory to physical 
//	memory.  For now, this is really simple (1:1), since we are
//	only uniprogramming, and we have a single unsegmented page table
//
//	"executable" is the file containing the object code to load into memory
//----------------------------------------------------------------------

ProcessAddressSpace::ProcessAddressSpace(OpenFile *executable)
{
    NoffHeader noffH;
    unsigned int i, size;
    unsigned vpn, offset;
    TranslationEntry *entry;
    unsigned int pageFrame;

    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    if ((noffH.noffMagic != NOFFMAGIC) && 
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);

// how big is address space?
    size = noffH.code.size + noffH.initData.size + noffH.uninitData.size 
			+ UserStackSize;	// we need to increase the size
						// to leave room for the stack
    numVirtualPages = divRoundUp(size, PageSize);
    size = numVirtualPages * PageSize;
    DEBUG('r', "@@@ numvirtualpages %d, numpagesallocated %d\n", numVirtualPages, numPagesAllocated);
    if(replacementAlgo == NO_REPLACEMENT)
        ASSERT(numVirtualPages+numPagesAllocated <= NumPhysPages);		// check we're not trying
										// to run anything too big --
										// at least until we have
										// virtual memory

    DEBUG('a', "Initializing address space, num pages %d, size %d\n", 
					numVirtualPages, size);
// first, set up the translation 
    KernelPageTable = new TranslationEntry[numVirtualPages];
    for (i = 0; i < numVirtualPages; i++) {
	KernelPageTable[i].virtualPage = i;
	KernelPageTable[i].physicalPage = i+numPagesAllocated;
	KernelPageTable[i].valid = FALSE;
	KernelPageTable[i].use = FALSE;
	KernelPageTable[i].dirty = FALSE;
	KernelPageTable[i].readOnly = FALSE;  // if the code segment was entirely on 
					// a separate page, we could set its 
					// pages to be read-only
    // assignment 3
    KernelPageTable[i].shared = FALSE;
    KernelPageTable[i].loadFromBackup = FALSE;
    }
// zero out the entire address space, to zero the unitialized data segment 
// and the stack segment
    // bzero(&machine->mainMemory[numPagesAllocated*PageSize], size);
 
    // numPagesAllocated += numVirtualPages;

// then, copy in the code and data segments into memory
// not sure what to do about this:
   //  if (noffH.code.size > 0) {
   //      DEBUG('a', "Initializing code segment, at 0x%x, size %d\n", 
			// noffH.code.virtualAddr, noffH.code.size);
   //      vpn = noffH.code.virtualAddr/PageSize;
   //      offset = noffH.code.virtualAddr%PageSize;
   //      entry = &KernelPageTable[vpn];
   //      pageFrame = entry->physicalPage;
   //      executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + offset]),
			// noffH.code.size, noffH.code.inFileAddr);
   //  }
   //  if (noffH.initData.size > 0) {
   //      DEBUG('a', "Initializing data segment, at 0x%x, size %d\n", 
			// noffH.initData.virtualAddr, noffH.initData.size);
   //      vpn = noffH.initData.virtualAddr/PageSize;
   //      offset = noffH.initData.virtualAddr%PageSize;
   //      entry = &KernelPageTable[vpn];
   //      pageFrame = entry->physicalPage;
   //      executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + offset]),
			// noffH.initData.size, noffH.initData.inFileAddr);
   //  }

}

//----------------------------------------------------------------------
// ProcessAddressSpace::ProcessAddressSpace (ProcessAddressSpace*) is called by a forked thread.
//      We need to duplicate the address space of the parent.
//----------------------------------------------------------------------


ProcessAddressSpace::ProcessAddressSpace(ProcessAddressSpace *parentSpace)
{
    numVirtualPages = parentSpace->GetNumPages();
    unsigned i, j, size = numVirtualPages * PageSize;
    unsigned pageFrame, parentPageFrame;
   // unsigned numSharedPages = 0, numNormalPages = 0;
    if(replacementAlgo == NO_REPLACEMENT )
        ASSERT(numVirtualPages+numPagesAllocated <= NumPhysPages);          // check we're not trying  to run anything too big
                                                                        // at least until we have virtual memory
    DEBUG('a', "Creating blank address space, num pages %d, size %d\n",
                                        numVirtualPages, size);
    // first, set up the translation
    //TranslationEntry* parentPageTable = parentSpace->GetPageTable();
    KernelPageTable = new TranslationEntry[numVirtualPages];
    //DEBUG('j',"\t\t\t\t\t\t ---------------------Parent pageframe, numVirtualPages %d\n", numVirtualPages);
    for (i = 0; i < numVirtualPages; i++) 
        KernelPageTable[i].initializeEntry(i);
}


//----------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------


void
ProcessAddressSpace::CopySpace(ProcessAddressSpace *parentSpace, char* parentBackupDisk, char* childBackupDisk, NachOSThread* child)
{
    numVirtualPages = parentSpace->GetNumPages();
    unsigned i, j, size = numVirtualPages * PageSize;
    unsigned pageFrame, parentPageFrame;
    unsigned numSharedPages = 0, numNormalPages = 0;
    if(replacementAlgo == NO_REPLACEMENT )
        ASSERT(numVirtualPages+numPagesAllocated <= NumPhysPages); // check we're not trying  to run anything too big
                                                                // at least until we have virtual memory
    DEBUG('a', "Initializing address space, num pages %d, size %d\n",
                                        numVirtualPages, size);
    // first, set up the translation
    TranslationEntry* parentPageTable = parentSpace->GetPageTable();
    //KernelPageTable = new TranslationEntry[numVirtualPages];
    DEBUG('j',"\t\t\t\t\t\t ---------------------Parent pageframe, numVirtualPages %d\n", numVirtualPages);
    for (i = 0; i < numVirtualPages; i++) {
        //KernelPageTable[i].initializeEntry(i);
        if(parentPageTable[i].shared && parentPageTable[i].valid){
            DEBUG('j',"\t\t\t\t\t\t ---------------------Found Shared Page: pageframe %d, assigned to vpn %d\n", parentPageTable[i].physicalPage, i);
            KernelPageTable[i].physicalPage = parentPageTable[i].physicalPage;
            KernelPageTable[i].valid = TRUE;
            KernelPageTable[i].shared = TRUE;
            ++numSharedPages;
            
            stats->PageFaultIncr();  //increment the number of page faults.
        }
        else if(parentPageTable[i].valid){
            DEBUG('j',"\t\t\t\t\t\t ----------------copying parent's valid Page: vpn %d, pframe %d\n", i, parentPageTable[i].physicalPage);
            
            if(replacementAlgo == NO_REPLACEMENT)
            {
                KernelPageTable[i].physicalPage = numPagesAllocated;
                KernelPageTable[i].valid = TRUE;
                unsigned startAddrParent = parentPageTable[i].physicalPage*PageSize;
                unsigned startAddrChild = KernelPageTable[i].physicalPage*PageSize;
                    //copy the contents of valid parent page frames.
                for(j=0; j<PageSize; ++j)
                {
                  machine->mainMemory[startAddrChild + j] = machine->mainMemory[startAddrParent + j];
                }
                ++numPagesAllocated;  // unshared pages
            }
            else
            {
                parentPageFrame = parentPageTable[i].physicalPage;
                pageFrame = parentPageFrame;
                DEBUG('j',"@@@--- Calling PageReplacementUpdater from fork pframe  %d\n", parentPageFrame);
                PageReplacementUpdater(parentPageFrame * PageSize); // to touch the parent page.
                while(pageFrame == parentPageFrame) 
                { // to avoid replacing the page to be copied.
                    machine->FindPageToReplace(&pageFrame);
                    
                }
                DEBUG('j', "@@@ returned from find page to replace in fork, going to replace pframe %d\n", pageFrame);
                DEBUG('j', "@@@ --- Freeing page %d\n", pageFrame);
                FreeThePage(pageFrame);
                DEBUG('j', "@@@ returned from free the page in fork, going to replace pframe %d\n", pageFrame);
                KernelPageTable[i].physicalPage = pageFrame;
                KernelPageTable[i].valid = TRUE;
                unsigned startAddrParent = parentPageTable[i].physicalPage*PageSize;
                unsigned startAddrChild = KernelPageTable[i].physicalPage*PageSize;
                    //copy the contents of valid parent page frames.
                for(j=0; j<PageSize; ++j)
                {
                  machine->mainMemory[startAddrChild + j] = machine->mainMemory[startAddrParent + j];
                }                               
            }
            
            machine->UpdateInversePageTableEntry(&(KernelPageTable[i]));
            machine->InverseKernelPageTable[pageFrame].thread = child;
            machine->InverseKernelPageTable[pageFrame].pid = child->GetPID();
            // *done* : you still have to update the status of this page in replacement algo.
            stats->PageFaultIncr();
            currentThread->SortedInsertInWaitQueue (PageFaultLatency + stats->totalTicks); //put this thred to sleep for a while.         
        }
        
        else if(parentPageTable[i].loadFromBackup)
        { // copy from parent's backup to child's backup.
            unsigned startAddrParent = i * PageSize;
            unsigned startAddrChild = i * PageSize;
            DEBUG('j',"backup called\n");
            DEBUG('j', "@@@ copying contents parent backup to child backup, staddrchild %d, staddrparent %d\n", startAddrChild, startAddrParent);
            for(j=0; j<PageSize; ++j)
            {
                
                childBackupDisk[startAddrChild + j] = parentBackupDisk[startAddrParent + j];
            }
            KernelPageTable[i].loadFromBackup = TRUE;
            KernelPageTable[i].dirty = TRUE;
        }

        KernelPageTable[i].valid = parentPageTable[i].valid;
        KernelPageTable[i].use = parentPageTable[i].use;
        KernelPageTable[i].dirty = parentPageTable[i].dirty;
        KernelPageTable[i].readOnly = parentPageTable[i].readOnly;  	// if the code segment was entirely on
                                        			// a separate page, we could set its
                                        			// pages to be read-only
        // assignment 3
    }
}

//----------------------------------------------------------------------
// ProcessAddressSpace::~ProcessAddressSpace
// 	Dealloate an address space.  Nothing for now!
//----------------------------------------------------------------------

ProcessAddressSpace::~ProcessAddressSpace()
{
   delete KernelPageTable;
}

//----------------------------------------------------------------------
// ProcessAddressSpace::InitUserModeCPURegisters
// 	Set the initial values for the user-level register set.
//
// 	We write these directly into the "machine" registers, so
//	that we can immediately jump to user code.  Note that these
//	will be saved/restored into the currentThread->userRegisters
//	when this thread is context switched out.
//----------------------------------------------------------------------

void
ProcessAddressSpace::InitUserModeCPURegisters()
{
    int i;

    for (i = 0; i < NumTotalRegs; i++)
	machine->WriteRegister(i, 0);   

    // Initial program counter -- must be location of "Start"
    machine->WriteRegister(PCReg, 0);	

    // Need to also tell MIPS where next instruction is, because
    // of branch delay possibility
    machine->WriteRegister(NextPCReg, 4);

   // Set the stack register to the end of the address space, where we
   // allocated the stack; but subtract off a bit, to make sure we don't
   // accidentally reference off the end!
    machine->WriteRegister(StackReg, numVirtualPages * PageSize - 16);
    DEBUG('a', "Initializing stack register to %d\n", numVirtualPages * PageSize - 16);
}

//----------------------------------------------------------------------
// ProcessAddressSpace::SaveContextOnSwitch
// 	On a context switch, save any machine state, specific
//	to this address space, that needs saving.
//
//	For now, nothing!
//----------------------------------------------------------------------

void ProcessAddressSpace::SaveContextOnSwitch() 
{}

//----------------------------------------------------------------------
// ProcessAddressSpace::RestoreContextOnSwitch
// 	On a context switch, restore the machine state so that
//	this address space can run.
//
//      For now, tell the machine where to find the page table.
//----------------------------------------------------------------------

void ProcessAddressSpace::RestoreContextOnSwitch() 
{
    machine->KernelPageTable = KernelPageTable;
    machine->KernelPageTableSize = numVirtualPages;
}

unsigned
ProcessAddressSpace::GetNumPages()
{
   return numVirtualPages;
}

TranslationEntry*
ProcessAddressSpace::GetPageTable()
{
   return KernelPageTable;
}

// assignment 3
void
ProcessAddressSpace::UpdateKernelPageTable(TranslationEntry* newPageTable, unsigned newVirtualPages)
{
    if(newPageTable == NULL)
    {
        DEBUG('a',"DEBUG -a- :: Trying to replace old KernelPageTable with NULL value\n");
        ASSERT(newPageTable != NULL);
        return;
    }
    delete KernelPageTable;
    KernelPageTable = newPageTable;
    numVirtualPages = newVirtualPages;
}

void
ProcessAddressSpace::UpdateKernelPageTableEntry(int virt_pn, int pageFrame)
{
    DEBUG('r',"@@@--- Inside UpdateKernelPageTableEntry vpn %d, pframe %d\n", virt_pn, pageFrame);
  if(virt_pn <= numVirtualPages && pageFrame <= NumPhysPages)
  {
    KernelPageTable[virt_pn].physicalPage = pageFrame;
    KernelPageTable[virt_pn].valid = TRUE;
    KernelPageTable[virt_pn].use = TRUE;  // I set use to true as it must have been queried.
    KernelPageTable[virt_pn].dirty = FALSE;
    KernelPageTable[virt_pn].readOnly = FALSE;  // if the code segment was entirely on 
          // a separate page, we could set its 
          // pages to be read-only
    // assignment 3
    KernelPageTable[virt_pn].shared = FALSE;
  }
}


void
ProcessAddressSpace::InvalidateKernelPageTableEntry(int virt_pn)
{
    DEBUG('r',"@@@--- Inside InvalidateKernelPageTableEntry vpn %d\n", virt_pn);
    KernelPageTable[virt_pn].valid = FALSE;
}

TranslationEntry*
ProcessAddressSpace::GetPageTableEntry(int vpn)
{
    DEBUG('r',"@@@--- Inside GetPageTableEntry vpn %d, numvirtpages %d\n", vpn, numVirtualPages);
    if(vpn < numVirtualPages )
        return &(KernelPageTable[vpn]);
    else 
        return NULL;
}
//----------------------------------------------------------------------
// HandlePageFault
// 	
//----------------------------------------------------------------------

void HandlePageFault(int vaddr)
{   
    DEBUG('r',"@@@--- Inside HandlePageFault vaddr %d\n", vaddr);
    if(replacementAlgo > 0) {
        PageReplacementHandler(vaddr);
    } 
    else 
    {
        unsigned int pageFrame;
        pageFrame = numPagesAllocated; // set the new pageframe as the next available physical page.
        ++numPagesAllocated; 

        LoadFromFile(vaddr, pageFrame);
        currentThread->space->UpdateKernelPageTableEntry(vaddr / PageSize, pageFrame);
        machine->UpdateInversePageTableEntry(&(machine->KernelPageTable[vaddr/PageSize]));
    }

    //DEBUG('e', "===========entering sorted insert in waitqueue, pid %d,  %d=======\n",currentThread->GetPID(), stats->totalTicks );
    currentThread->SortedInsertInWaitQueue (PageFaultLatency + stats->totalTicks); // put this thred to sleep.
    //DEBUG('e', "===========exiting sorted insert in waitqueue, pid %d,  %d=======\n", currentThread->GetPID(), stats->totalTicks );


}

void 
PageReplacementUpdater(int physAddr)
{
    // update lru and lru clock here, and also in WriteMem.
    //assuming the translation is valid and the inversePageTable is consistent/valid
    if(replacementAlgo == NO_REPLACEMENT)
        return;
    unsigned pageFrame = physAddr / PageSize ;
    DEBUG('r',"@@@--- Inside PRU physAddr/pframe 0x%x %d/%d\n",physAddr, physAddr, pageFrame);
    DoubleListElement* element;
    ASSERT(machine->InverseKernelPageTable[pageFrame].valid);
    if(replacementAlgo == LRU)
    {
      element = machine->InverseKernelPageTable[pageFrame].pageFrameNodePtr;
      // update LRUlist on memory access.
      DEBUG('r', "inside PRU with physaddr: %d/0x%x, pframe %d, valid status for invPageTable %d, by pid %d\n", physAddr, physAddr, pageFrame ,machine->InverseKernelPageTable[pageFrame].valid , currentThread->GetPID());
      IntStatus oldLevel = interrupt->SetLevel(IntOff);
      machine->LRUlist->MoveToFront(element);
      (void) interrupt->SetLevel(oldLevel);
    }
    else if(replacementAlgo == LRU_CLOCK)
    {
        machine->LRUClock->setBit(pageFrame); 
    }
    DEBUG('r',"@@@--- Done Updating physAddr %d\n", physAddr);
}

void 
PageReplacementHandler(int vaddr)
{
    DEBUG('r', "@@@ Inside PRH, vaddr %d\n", vaddr);
    unsigned int pageFrame;
    unsigned vpn, offset, oldvpn ,strAddrDisk, strAddrMemory;
    unsigned int i, j, size;
    bool flag;
    NachOSThread* oldThread;
    TranslationEntry* entry, old_entry;
    InverseTranslationEntry* inv_entry;
    
    machine->FindPageToReplace( &pageFrame);
    FreeThePage(pageFrame);
    
    vpn = vaddr / PageSize;
    currentThread->space->UpdateKernelPageTableEntry(vpn, pageFrame);
    entry = currentThread->space->GetPageTableEntry(vpn);
    machine->UpdateInversePageTableEntry(entry);   // update the inverse page table.
    LoadThePage(vaddr, pageFrame);
}

// create nodes in  lru as the pageframe is 1st accessed to avoid inserting
// shared page frames into it..

void
LoadFromFile(int vaddr, int pageFrame)
{   
    ASSERT( vaddr >=0 && pageFrame >=0 && pageFrame < NumPhysPages );
    DEBUG('r',"@@@--- Inside LoadFromFile vaddr/pframe %d/%d\n", vaddr, pageFrame);
    NoffHeader noffH;
    unsigned int i, size, vpn;
    TranslationEntry *entry;
    unsigned int  addr_in_exe;
    //NachOSThread *thisThread = currentThread;

    vpn = vaddr / PageSize;
    
    char filename[1024];
    currentThread->GetFilename(filename);
    OpenFile *executable =  fileSystem->Open(filename);

    if (executable == NULL) {
        printf("Unable to open file %s\n", filename);
        return;
    }
    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);

    if ((noffH.noffMagic != NOFFMAGIC) && 
    (WordToHost(noffH.noffMagic) == NOFFMAGIC))
    SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);
    
    // currentThread->space->UpdateKernelPageTableEntry(vpn, pageFrame); // update the kernel page-table entry
    // bring the page into memory.
    bzero(&(machine->mainMemory[pageFrame * PageSize]), PageSize); // zero out the page.

    if(0) // not doing..
    {
        executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + 0]), PageSize, vpn * PageSize);
    }
    
    else if(noffH.code.virtualAddr <= vaddr && vaddr <= noffH.code.virtualAddr + noffH.code.size)
    {
        DEBUG('p',"DEBUG -e- :: inside noffH.code.virtualAddr\n");
        //DEBUG('e',"code offset::\t %d\n", noffH.code.inFileAddr - noffH.code.virtualAddr);
        addr_in_exe = (noffH.code.inFileAddr - noffH.code.virtualAddr + vpn * PageSize);
        executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + 0]), PageSize, addr_in_exe);
    }

    else if(noffH.initData.virtualAddr <= vaddr && vaddr <= noffH.initData.virtualAddr + noffH.initData.size)
    {
        DEBUG('p',"DEBUG -e- :: inside noffH.initData.virtualAddr\n");
        addr_in_exe = (noffH.initData.inFileAddr - noffH.initData.virtualAddr + vpn * PageSize);
        executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + 0]), PageSize, addr_in_exe);
    }
    else if(noffH.uninitData.virtualAddr <= vaddr && vaddr <= noffH.uninitData.virtualAddr + noffH.uninitData.size)
    {   // shouldn't read from it., i have assumed it to zero.
        DEBUG('o',"DEBUG -e- :: inside noffH.uninitData.virtualAddr\n");
        addr_in_exe = (noffH.initData.inFileAddr - noffH.initData.virtualAddr + vpn * PageSize);
        //executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + 0]), PageSize, addr_in_exe);
    }
    else
    {       // won't read from it.
        DEBUG('o',"DEBUG -e- ::  Accessing virtual address beyond the code, initialized data or uninitialized data.\n");
        addr_in_exe =  StackSize + (vpn * PageSize);
        executable->ReadAt(&(machine->mainMemory[pageFrame * PageSize + 0]), PageSize, addr_in_exe);     
    }
    delete executable;
    DEBUG('p',"@@@--- Done LoadingFromFile vaddr/pframe %d/%d\n", vaddr, pageFrame);
}

int 
Machine::FindPageToReplace(unsigned *pframe)
{
    unsigned int pageFrame;
    bool flag;
    DEBUG('r',"@@@--- Inside FindPageToReplace  \n");
    if(numPagesAllocated < NumPhysPages)
    {
        pageFrame = numPagesAllocated;
        if(replacementAlgo == LRU){
            LRUlist->Prepend(pageFrame);
            InverseKernelPageTable[pageFrame].pageFrameNodePtr = LRUlist->GetFirst();
            DEBUG('r', "@@@@---LRU element: %d\n", (LRUlist->GetFirst())->item);
        }
        else if(replacementAlgo == FIFO){
            FIFOQueue->Prepend(pageFrame);
            InverseKernelPageTable[pageFrame].pageFrameNodePtr = FIFOQueue->GetFirst();
            DEBUG('r', "@@@@---Inserted FIFO element: %d\n", (FIFOQueue->GetFirst())->item);
        }
        
        else if(replacementAlgo == LRU_CLOCK)
        {
            flag = 1;
            while( flag )
            { // all this hasle to avoid replacing a shared page.
                pageFrame = LRUClock->FindNextLow();
                if(!InverseKernelPageTable[pageFrame].shared)
                    flag = 0;
            }
        }
        ++numPagesAllocated;
        DEBUG('r', "@@@ numPagesAllocated %d\n", numPagesAllocated);        
    }
    
    else if( numPagesAllocated == NumPhysPages)
    {
        if(replacementAlgo == LRU )
        {
            flag = 1;
            while( flag )
            { // all this hasle to avoid replacing a shared page.
                pageFrame = (LRUlist->GetLast())->item;
                if(!InverseKernelPageTable[pageFrame].shared)
                    flag = 0;
                DEBUG('p',"@@@@@---Inside FPTR, LRU, pageframe %d\n", pageFrame);
                
                IntStatus oldLevel = interrupt->SetLevel(IntOff);
                LRUlist->MoveToFront(LRUlist->GetLast());
                (void) interrupt->SetLevel(oldLevel);
            }
        }
        else if(replacementAlgo == FIFO)
        {
            flag = 1;
            while( flag )
            { // all this hasle to avoid replacing a shared page.
                pageFrame = (FIFOQueue->GetLast())->item;
                if(!InverseKernelPageTable[pageFrame].shared)
                    flag = 0;
                DEBUG('p',"@@@@@---Inside FPTR, FIFO, pageframe %d\n", pageFrame);
                
                IntStatus oldLevel = interrupt->SetLevel(IntOff);                
                FIFOQueue->MoveToFront(FIFOQueue->GetLast());
                (void) interrupt->SetLevel(oldLevel);
            }
        }
        else if(replacementAlgo == LRU_CLOCK)
        {
            flag = 1;
            while( flag )
            { // all this hasle to avoid replacing a shared page.
                pageFrame = LRUClock->FindNextLow();
                if(!InverseKernelPageTable[pageFrame].shared)
                    flag = 0;
            }
        }
        else if(replacementAlgo == RANDOM)
        {
            flag = 1;
            while( flag )
            { // all this hasle to avoid replacing a shared page.
                pageFrame = Random() % NumPhysPages;
                if(!InverseKernelPageTable[pageFrame].shared)
                    flag = 0;
            }
        }
        else
            ASSERT(FALSE);
    }
    *pframe = pageFrame;
    DEBUG('r', "@@@ page to replace sent...\n");
    return 1;
}

void 
FreeThePage(int pageFrame)
{   
    ASSERT(pageFrame < NumPhysPages);
    unsigned oldvpn ,strAddrDisk, strAddrMemory;
    unsigned int i;
    DEBUG('r', "@@@ Freeing Page %d called by [pid: %d]\n", pageFrame, currentThread->GetPID());
    NachOSThread* oldThread;
    TranslationEntry* entry, *old_entry;
    InverseTranslationEntry* inv_entry;
    
    DEBUG('r', "@@@ F1\n");
    inv_entry = &(machine->InverseKernelPageTable[pageFrame]);
    if(inv_entry->valid == FALSE){
        DEBUG('r', "@@@ Page %d already invalid\n", pageFrame);
        return;
    }
    //DEBUG('r', "@@@ F2\n");
    oldThread = inv_entry->thread;
    oldvpn = inv_entry->virtualPage;
    //DEBUG('r', "@@@ F3\n");
    ASSERT(oldThread!=NULL);
    DEBUG('r', "@@@ oldThread pid: %d\n", oldThread->GetPID());
    //DEBUG('r', "@@@ F3-1 \n");
    ASSERT(oldThread->space != NULL);
    //DEBUG('r', "@@@ F3-2\n");
    old_entry = oldThread->space->GetPageTableEntry(oldvpn); // of the thread whose page is being replaced.
    //DEBUG('r', "@@@ F4\n");
    DEBUG('r',"@@@--- returned from GetPageTableEntry %d\n");
    if(old_entry->dirty) //save it to buffer
    {
        strAddrDisk = oldvpn * PageSize;
        strAddrMemory = pageFrame * PageSize;
        for(i=0; i< PageSize; ++i)
        {
            oldThread->backupDisk[strAddrDisk + i] = machine->mainMemory[strAddrMemory + i];
        }
        old_entry->loadFromBackup = TRUE;
    }
    old_entry->valid = FALSE; // invalidate the entry of process whose page got replaced.
    inv_entry->valid = FALSE;
    DEBUG('r', "@@@ Page %d Freed\n", pageFrame);
}

void 
LoadThePage(int vaddr, int pageFrame)
{
    DEBUG('r',"@@@--- Inside LoadThePage vaddr/pframe %d/%d\n", vaddr, pageFrame);
    unsigned vpn = vaddr / PageSize, i;
    if(machine->KernelPageTable[vpn].loadFromBackup) // if page is in backup
    {   
        DEBUG('r',"@@@--- loading from backup, vaddr/pframe %d/%d\n", vaddr, pageFrame);
        unsigned strAddrDisk = vpn * PageSize;
        unsigned strAddrMemory = pageFrame * PageSize;
        for(i=0; i< PageSize; ++i)
        {
            machine->mainMemory[strAddrMemory + i] = currentThread->backupDisk[strAddrDisk + i];
        }
    }
    else // read page from executable.
        LoadFromFile(vaddr, pageFrame); 
    DEBUG('r',"@@@--- Done Loading vaddr/pframe %d/%d\n", vaddr, pageFrame);
}

