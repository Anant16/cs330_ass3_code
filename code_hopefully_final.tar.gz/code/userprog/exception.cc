// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"
#include "console.h"
#include "synch.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------
static Semaphore *readAvail;
static Semaphore *writeDone;
static void ReadAvail(int arg) { readAvail->V(); }
static void WriteDone(int arg) { writeDone->V(); }

extern void LaunchUserProcess (char*);

void
ForkStartFunction (int dummy)
{
   currentThread->Startup();
   machine->Run();
}

static void ConvertIntToHex (unsigned v, Console *console)
{
   unsigned x;
   if (v == 0) return;
   ConvertIntToHex (v/16, console);
   x = v % 16;
   if (x < 10) {
      writeDone->P() ;
      console->PutChar('0'+x);
   }
   else {
      writeDone->P() ;
      console->PutChar('a'+x-10);
   }
}

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    int memval, vaddr, printval, tempval, exp;
    unsigned printvalus;	// Used for printing in hex
    if (!initializedConsoleSemaphores) {
       readAvail = new Semaphore("read avail", 0);
       writeDone = new Semaphore("write done", 1);
       initializedConsoleSemaphores = true;
    }
    Console *console = new Console(NULL, NULL, ReadAvail, WriteDone, 0);
    int exitcode;		// Used in SysCall_Exit
    unsigned i;
    char buffer[1024];		// Used in SysCall_Exec
    int waitpid;		// Used in SysCall_Join
    int whichChild;		// Used in SysCall_Join
    NachOSThread *child;		// Used by SysCall_Fork
    unsigned sleeptime;		// Used by SysCall_Sleep

    if ((which == SyscallException) && (type == SysCall_Halt)) {
	DEBUG('a', "Shutdown, initiated by user program.\n");
   	interrupt->Halt();
    }
    else if ((which == SyscallException) && (type == SysCall_Exit)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Exit\n");
       exitcode = machine->ReadRegister(4);
       printf("[pid %d]: Exit called. Code: %d\n", currentThread->GetPID(), exitcode);
       // We do not wait for the children to finish.
       // The children will continue to run.
       // We will worry about this when and if we implement signals.
       exitThreadArray[currentThread->GetPID()] = true;

       // Find out if all threads have called exit
       for (i=0; i<thread_index; i++) {
          if (!exitThreadArray[i]) break;
       }
       
       //---------------- brought from scheduler.cc-----
        // free up the inverse kernel page table
        int j, numVpages, dying_pid;
        numVpages = currentThread->space->GetNumPages();
        dying_pid = currentThread->GetPID();
        for( j=0; j < NumPhysPages; ++j )
        {
            if(machine->InverseKernelPageTable[j].pid == dying_pid && !machine->InverseKernelPageTable[j].shared)
            {
                machine->InverseKernelPageTable[j].valid = FALSE;
                DEBUG('j', "Page freed from dying process[%d]: %d\n", dying_pid, j);   
            }
        }
    //-----------------------------------------------
       //DEBUG('j', "i=%d, thread_index=%d\n", i, );
       currentThread->Exit(i==thread_index, exitcode);
    }
    else if ((which == SyscallException) && (type == SysCall_Exec)) {
       // Copy the executable name into kernel space
       DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Exec by pid %d\n", currentThread->GetPID());
       vaddr = machine->ReadRegister(4);
       while(!machine->ReadMem(vaddr, 1, &memval)) DEBUG('j',"\t\t\t\t\tDEBUG -e- :: PageFault in ReadMem_2\n") ; //assignment 3
       i = 0;
       while ((*(char*)&memval) != '\0') {
          buffer[i] = (*(char*)&memval);
          i++;
          vaddr++;
          while(!machine->ReadMem(vaddr, 1, &memval)) DEBUG('j',"\t\t\t\t\tDEBUG -e- :: PageFault in ReadMem_3\n") ;
       }
       buffer[i] = (*(char*)&memval);
       LaunchUserProcess(buffer);
    }
    else if ((which == SyscallException) && (type == SysCall_Join)) {
       waitpid = machine->ReadRegister(4);
       DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Join by pid %d\n", currentThread->GetPID());
       // Check if this is my child. If not, return -1.
       whichChild = currentThread->CheckIfChild (waitpid);
       if (whichChild == -1) {
          printf("[pid %d] Cannot join with non-existent child [pid %d].\n", currentThread->GetPID(), waitpid);
          machine->WriteRegister(2, -1);
          // Advance program counters.
          machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
          machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
          machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
       }
       else {
          exitcode = currentThread->JoinWithChild (whichChild);
          machine->WriteRegister(2, exitcode);
          // Advance program counters.
          machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
          machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
          machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
       }
    }
    else if ((which == SyscallException) && (type == SysCall_Fork)) {
       // Advance program counters.
       DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Fork by pid %d\n", currentThread->GetPID());
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
       
       char fname[1024]; // assignment 3 , for file name(executable)
       currentThread->GetFilename(fname);
       child = new NachOSThread("Forked thread", GET_NICE_FROM_PARENT);
       // create backup disk / array for child thread for page replacement.
       child->backupDisk = new char[PageSize * currentThread->space->GetNumPages()];
       child->space = new ProcessAddressSpace (currentThread->space);  // Duplicates the address space
       child->space->CopySpace(currentThread->space, currentThread->backupDisk, child->backupDisk, child);
       
       child->SetFilename(fname);  // assignment 3 - to be able to read from the executable later.
       
       child->SaveUserState ();		     		      // Duplicate the register set
       child->ResetReturnValue ();			     // Sets the return register to zero
       child->CreateThreadStack (ForkStartFunction, 0);	// Make it ready for a later context switch
       child->Schedule ();
       machine->WriteRegister(2, child->GetPID());		// Return value for parent
    }
    else if ((which == SyscallException) && (type == SysCall_Yield)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Yield by pid %d\n", currentThread->GetPID());
       currentThread->YieldCPU();
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_PrintInt)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_PrintInt by pid %d\n", currentThread->GetPID());
       printval = machine->ReadRegister(4);
       if (printval == 0) {
          writeDone->P() ;
          console->PutChar('0');
       }
       else {
          if (printval < 0) {
             writeDone->P() ;
             console->PutChar('-');
             printval = -printval;
          }
          tempval = printval;
          exp=1;
          while (tempval != 0) {
             tempval = tempval/10;
             exp = exp*10;
          }
          exp = exp/10;
          while (exp > 0) {
             writeDone->P() ;
             console->PutChar('0'+(printval/exp));
             printval = printval % exp;
             exp = exp/10;
          }
       }
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_PrintChar)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_PrintChar by pid %d\n", currentThread->GetPID());
        writeDone->P() ;        // wait for previous write to finish
        console->PutChar(machine->ReadRegister(4));   // echo it!
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_PrintString)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_PrintString by pid %d\n", currentThread->GetPID());
       vaddr = machine->ReadRegister(4);
       while( !machine->ReadMem(vaddr, 1, &memval) )  DEBUG('j',"\t\t\t\t\tDEBUG -e- :: PageFault in ReadMem\n") ;
       DEBUG('j',"\n=====================Now begining printing in syscall_printstr by pid %d=========\n", currentThread->GetPID());
       while ((*(char*)&memval) != '\0') {
          writeDone->P() ;
          console->PutChar(*(char*)&memval);
          vaddr++;
          while( !machine->ReadMem(vaddr, 1, &memval) ) DEBUG('j',"\t\t\t\t\tDEBUG -e- :: PageFault in ReadMem_1\n") ;
       }
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_GetReg)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_GetReg by pid %d\n", currentThread->GetPID());
       machine->WriteRegister(2, machine->ReadRegister(machine->ReadRegister(4))); // Return value
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_GetPA)) {
       vaddr = machine->ReadRegister(4);
       DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_GetPA by pid %d\n", currentThread->GetPID());
       machine->WriteRegister(2, machine->GetPA(vaddr));  // Return value
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_GetPID)) {
       machine->WriteRegister(2, currentThread->GetPID());
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_GetPPID)) {
       machine->WriteRegister(2, currentThread->GetPPID());
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_Sleep)) {
    DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_Sleep by pid %d\n", currentThread->GetPID());
       sleeptime = machine->ReadRegister(4);
       if (sleeptime == 0) {
          // emulate a yield
          currentThread->YieldCPU();
       }
       else {
          currentThread->SortedInsertInWaitQueue (sleeptime+stats->totalTicks);
       }
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_Time)) {
       machine->WriteRegister(2, stats->totalTicks);
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_PrintIntHex)) {
       printvalus = (unsigned)machine->ReadRegister(4);
       writeDone->P() ;
       console->PutChar('0');
       writeDone->P() ;
       console->PutChar('x');
       if (printvalus == 0) {
          writeDone->P() ;
          console->PutChar('0');
       }
       else {
          ConvertIntToHex (printvalus, console);
       }
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if ((which == SyscallException) && (type == SysCall_NumInstr)) {
    DEBUG('e',"\t\t\t\t\tDEBUG -e- :: inside SysCall_NumInstr\n");
       machine->WriteRegister(2, currentThread->GetInstructionCount());
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
    }
    else if((which == SyscallException) && (type == SysCall_ShmAllocate)) 
    {
        DEBUG('e',"\t\t\t\t\t\t\t\t\t\t\t\tDEBUG -e- :: inside SysCall_ShmAllocate by pid %d\n", currentThread->GetPID());
       int sharedMemorySize = machine->ReadRegister(4);
       int extraVirtualPages = divRoundUp(sharedMemorySize, PageSize);
       DEBUG('e',"\t\t\t\t\t\t\t\textra mem size %d page(s)\n", extraVirtualPages);
       DEBUG('e',"?????  extraVirtPages %d, numPagesAlllocated %d, NumPhysPages %d\n" , extraVirtualPages, numPagesAllocated, NumPhysPages);
       if(replacementAlgo == NO_REPLACEMENT)
           ASSERT(extraVirtualPages+numPagesAllocated <= NumPhysPages);
       int numVirtualPages = currentThread->space->GetNumPages();
       int newVirtualPages = numVirtualPages + extraVirtualPages;
       unsigned pageFrame;
       TranslationEntry *KernelPageTable = new TranslationEntry[newVirtualPages];
       TranslationEntry *oldPageTable = currentThread->space->GetPageTable();
       DEBUG('j',"$$$$$$ Copying old pagetableentries to new one.\n");
       for (i = 0; i < numVirtualPages; i++) 
       {
            KernelPageTable[i].copyEntry(&(oldPageTable[i]));
    	}
    	if(replacementAlgo == NO_REPLACEMENT)
	    {
	       	for (i = numVirtualPages; i < newVirtualPages; ++i)
       	       {
       	            DEBUG('j',"\t\t\t --------------------- Shared Page: pageframe %d, assigned to vpn %d\n", (i-numVirtualPages) + numPagesAllocated, i);
       	       		KernelPageTable[i].initializeEntry(i);
       		        KernelPageTable[i].physicalPage = (i-numVirtualPages) + numPagesAllocated;
       		        KernelPageTable[i].valid = TRUE;
       		        KernelPageTable[i].shared = TRUE;
       	       }
       	       numPagesAllocated += extraVirtualPages;
	    }
	    else
	    {
	        DEBUG('j',"$$$$$$ setting up shared pages in shm_alloc\n");
	    	for (i = numVirtualPages; i < newVirtualPages; ++i)
	    	{
	    		machine->FindPageToReplace(&pageFrame);
	        	FreeThePage(pageFrame);
	        	KernelPageTable[i].initializeEntry(i);
   		        KernelPageTable[i].physicalPage = pageFrame;
   		        KernelPageTable[i].valid = TRUE;	
   		        KernelPageTable[i].shared = TRUE;
   		        machine->UpdateInversePageTableEntry( &(KernelPageTable[i]) );
   		        DEBUG('j',"$$$$$$ pageFrame %d is now shared... with virtaddr %d\n", pageFrame, i);
	    	}
	    	DEBUG('j',"$$$$$$ Shared Pages are now set up.\n");
	    }       		

       //DEBUG('j',"\t\t\t\t\t\t --------------------ShmAllocate oldVirtulPages %d\n", numVirtualPages);
       currentThread->space->UpdateKernelPageTable(KernelPageTable, newVirtualPages);
       currentThread->space->RestoreContextOnSwitch();  // to update the machine->KernelePageTable
       													// and machine->numVirtualPages.
       machine->WriteRegister(2, numVirtualPages * PageSize); //virtual address of the first shared page.
       // Advance program counters.
       machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
       machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
       machine->WriteRegister(NextPCReg, machine->ReadRegister(NextPCReg)+4);
       DEBUG('j',"$$$$$$ Returning from shm_alloc\n");
	 
    }
    else if(which == PageFaultException)
    {
		stats->PageFaultIncr();
		int vaddr = machine->ReadRegister(BadVAddrReg);
		DEBUG('j', "\n\nInside PageFaultException # %d, vaddr %d, vaddr 0x%x, vpn %d, pid %d\n", stats->numPageFaults, vaddr, vaddr, vaddr/PageSize, currentThread->GetPID());
		HandlePageFault(vaddr);
    }
    else {
		printf("Unexpected user mode exception %d %d\n", which, type);
		ASSERT(FALSE);
    }
}
